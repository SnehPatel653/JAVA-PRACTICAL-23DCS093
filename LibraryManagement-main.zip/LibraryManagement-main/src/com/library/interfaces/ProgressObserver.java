package com.library.interfaces;

public interface ProgressObserver {
    void update(String message);
}
